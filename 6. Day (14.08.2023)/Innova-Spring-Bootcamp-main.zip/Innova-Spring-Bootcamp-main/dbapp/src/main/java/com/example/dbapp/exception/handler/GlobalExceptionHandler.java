package com.example.dbapp.exception.handler;

public class GlobalExceptionHandler {

}
